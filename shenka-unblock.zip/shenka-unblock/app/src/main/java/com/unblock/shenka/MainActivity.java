package com.unblock.shenka;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        TextView tv = new TextView(this);
        tv.setText("神卡密破解模块 v1.0\n\n" +
                "使用方法：\n" +
                "1. 安装 LSPosed\n" +
                "2. 在 LSPosed 中启用此模块\n" +
                "3. 将模块作用域设为 '神' APP\n" +
                "4. 重启 '神' APP\n\n" +
                "模块已自动绕过：\n" +
                "• 卡密验证\n" +
                "• 过期检查\n" +
                "• 网络验证\n" +
                "• JS 引擎验证\n\n" +
                "输入任意卡密即可激活！");
        tv.setPadding(32, 32, 32, 32);
        tv.setTextSize(14);
        setContentView(tv);
    }
}
