package com.unblock.shenka;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

import android.util.Log;

import java.lang.reflect.Method;

public class XposedModule implements IXposedHookLoadPackage {
    
    private static final String TAG = "ShenKaUnblock";
    private static final String TARGET_PACKAGE = "top.bienvenido.saas.i18n";
    
    // 伪造数据
    private static final String FAKE_EXPIRE = "2099-12-31 23:59:59";
    private static final String FAKE_LEVEL = "VIP";
    private static final String FAKE_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE4OTM0NTYwMDAsImxldmVsIjoiVklQIiwidHlwZSI6ImF1dGgiLCJ1c2VyIjoiZ2VzdCJ9.signature";
    
    private static final String FAKE_RESPONSE = "{\"code\":200,\"msg\":\"success\",\"success\":true,\"data\":{\"is_valid\":true,\"activated\":true,\"license_key\":\"VALIDATED\",\"expire_time\":\"2099-12-31 23:59:59\",\"remain_days\":9999,\"level\":\"VIP\",\"features\":[\"all\"]}}";
    
    private static final String FAKE_APPS = "{\"source\":\"main\",\"apps\":[{\"package\":\"net_62v.app.govern\",\"version\":99,\"title\":\"XGovern\",\"description\":\"X控制\",\"type\":1,\"uri\":\"http://spatch.die.lu/static/spromoter.apk\"}]}";
    
    @Override
    public void handleLoadPackage(LoadPackageParam lpp) throws Throwable {
        if (!lpp.packageName.equals(TARGET_PACKAGE)) return;
        
        Log.i(TAG, "===== 神卡密破解模块已加载 =====");
        
        try {
            hookSharedPreferences(lpp);
            hookJSengine(lpp);
            hookInvocationHandler(lpp);
            hookAccountResponse(lpp);
            hookOkHttp(lpp);
            hookExpiryChecks(lpp);
        } catch (Throwable t) {
            Log.e(TAG, "Hook 失败: " + t.getMessage(), t);
        }
        
        Log.i(TAG, "===== 所有 Hook 已安装 =====");
    }
    
    // ===== Hook 1: SharedPreferences =====
    private void hookSharedPreferences(LoadPackageParam lpp) {
        try {
            XposedHelpers.findAndHookMethod("android.content.SharedPreferences", lpp.classLoader,
                    "getString", String.class, String.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            String key = (String) param.args[0];
                            
                            if ("savedCard".equals(key)) {
                                param.setResult("XGOV-PERM-VIP-2099");
                                Log.i(TAG, "[SP] savedCard -> 伪造");
                            } else if ("cardPrefs".equals(key)) {
                                param.setResult("true");
                                Log.i(TAG, "[SP] cardPrefs -> 伪造");
                            } else if ("authToken".equals(key)) {
                                param.setResult(FAKE_TOKEN);
                                Log.i(TAG, "[SP] authToken -> 伪造");
                            } else if ("cardExpire".equals(key)) {
                                param.setResult(FAKE_EXPIRE);
                            } else if ("cardLevel".equals(key)) {
                                param.setResult(FAKE_LEVEL);
                            }
                        }
                    });
            
            XposedHelpers.findAndHookMethod("android.content.SharedPreferences", lpp.classLoader,
                    "getBoolean", String.class, boolean.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            String key = (String) param.args[0];
                            
                            if ("isActivated".equals(key) || "cardValid".equals(key) || "isValid".equals(key) || "cardPrefs".equals(key)) {
                                param.setResult(true);
                                Log.i(TAG, "[SP] " + key + " -> true");
                            }
                        }
                    });
            
            XposedHelpers.findAndHookMethod("android.content.SharedPreferences", lpp.classLoader,
                    "getInt", String.class, int.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            String key = (String) param.args[0];
                            
                            if ("remain_days".equals(key) || "remainDays".equals(key)) {
                                param.setResult(9999);
                            }
                        }
                    });
            
            Log.i(TAG, "[SP] SharedPreferences hook 成功");
        } catch (Throwable t) {
            Log.w(TAG, "[SP] SharedPreferences hook 失败: " + t.getMessage());
        }
    }
    
    // ===== Hook 2: JS 引擎 SBJSN =====
    private void hookJSengine(LoadPackageParam lpp) {
        try {
            // Hook SBJSN 的所有方法
            XposedHelpers.findAndHookMethods("LSBJSN0.SBJSN", lpp.classLoader, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String methodName = param.method.getName();
                    
                    if (methodName.contains("eval") || methodName.contains("Execut") || methodName.contains("Run")) {
                        Log.i(TAG, "[JS] " + methodName + "() -> 伪造成功");
                        if (param.method.getReturnType() == boolean.class) {
                            param.setResult(true);
                        } else if (param.method.getReturnType() == String.class) {
                            param.setResult("true");
                        }
                    }
                }
            });
            
            // Hook Hidden0
            XposedHelpers.findAndHookMethods("LSBJSN0.hidden.Hidden0", lpp.classLoader, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (param.method.getReturnType() == boolean.class) {
                        param.setResult(true);
                    }
                }
            });
            
            Log.i(TAG, "[JS] SBJSN/Hidden0 hook 成功");
        } catch (Throwable t) {
            Log.w(TAG, "[JS] SBJSN hook 失败: " + t.getMessage());
        }
    }
    
    // ===== Hook 3: 代理拦截 MInvocationHandler =====
    private void hookInvocationHandler(LoadPackageParam lpp) {
        try {
            XposedHelpers.findAndHookMethod("top.bienvenido.mundo.blockade.sm.MInvocationHandler", lpp.classLoader,
                    "invoke", Object.class, Method.class, Object[].class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            Method method = (Method) param.args[1];
                            String methodName = method.getName();
                            
                            if (methodName.contains("valid") || methodName.contains("check") || methodName.contains("verify") || methodName.contains("activat")) {
                                param.setResult(true);
                                Log.i(TAG, "[INV] 拦截 " + methodName + " -> true");
                            }
                        }
                    });
            
            Log.i(TAG, "[INV] MInvocationHandler hook 成功");
        } catch (Throwable t) {
            Log.w(TAG, "[INV] MInvocationHandler hook 失败: " + t.getMessage());
        }
    }
    
    // ===== Hook 4: 账户响应 =====
    private void hookAccountResponse(LoadPackageParam lpp) {
        try {
            // Hook MundoAccountResponse
            XposedHelpers.findAndHookMethods("top.bienvenido.mundo.common.ext.MundoAccountResponse", lpp.classLoader, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String methodName = param.method.getName().toLowerCase();
                    
                    if (methodName.contains("valid") || methodName.contains("activat") || methodName.contains("expire") || methodName.contains("premium") || methodName.contains("vip")) {
                        if (param.method.getReturnType() == boolean.class) {
                            param.setResult(true);
                            Log.i(TAG, "[ACC] " + param.method.getName() + "() -> true");
                        } else if (param.method.getReturnType() == int.class) {
                            param.setResult(9999);
                        }
                    }
                }
            });
            
            // Hook MundoAccountSession
            XposedHelpers.findAndHookMethods("top.bienvenido.mundo.common.ext.MundoAccountSession", lpp.classLoader, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String methodName = param.method.getName().toLowerCase();
                    
                    if (methodName.contains("valid") || methodName.contains("activat") || methodName.contains("expire")) {
                        if (param.method.getReturnType() == boolean.class) {
                            param.setResult(true);
                        }
                    }
                }
            });
            
            Log.i(TAG, "[ACC] 账户响应 hook 成功");
        } catch (Throwable t) {
            Log.w(TAG, "[ACC] 账户响应 hook 失败: " + t.getMessage());
        }
    }
    
    // ===== Hook 5: OkHttp3 网络请求 =====
    private void hookOkHttp(LoadPackageParam lpp) {
        try {
            XposedHelpers.findAndHookMethod("okhttp3.RealCall", lpp.classLoader,
                    "getResponseWithInterceptorChain", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            // 获取 request
                            Object request = XposedHelpers.callMethod(param.thisObject, "request");
                            String url = (String) XposedHelpers.callMethod(request, "url");
                            
                            if (url == null) {
                                url = request.toString();
                            }
                            
                            Log.i(TAG, "[NET] >> " + url);
                            
                            // 拦截 dapps.php
                            if (url.contains("dapps.php")) {
                                Log.i(TAG, "[+] 拦截 dapps.php");
                                Object fakeResp = createFakeResponse(param.thisObject, FAKE_APPS);
                                param.setResult(fakeResp);
                                return;
                            }
                            
                            // 拦截 backend 请求
                            if (url.contains("backend.purecheat.com")) {
                                Log.i(TAG, "[+] 拦截 backend 请求");
                                Object fakeResp = createFakeResponse(param.thisObject, FAKE_RESPONSE);
                                param.setResult(fakeResp);
                                return;
                            }
                        }
                    });
            
            Log.i(TAG, "[NET] OkHttp3 hook 成功");
        } catch (Throwable t) {
            Log.w(TAG, "[NET] OkHttp3 hook 失败: " + t.getMessage());
        }
    }
    
    private Object createFakeResponse(Object call, String json) {
        try {
            // 使用反射创建响应
            String requestClassName = "okhttp3.Request";
            String responseClassName = "okhttp3.Response";
            
            // 获取 request
            Object request = XposedHelpers.callMethod(call, "request");
            
            // 创建 ResponseBody
            Class<?> mediaTypeClass = Class.forName("okhttp3.MediaType", true, call.getClass().getClassLoader());
            Object mediaType = mediaTypeClass.getMethod("parse", String.class).invoke(null, "application/json");
            
            Class<?> responseBodyClass = Class.forName("okhttp3.ResponseBody", true, call.getClass().getClassLoader());
            Object body = responseBodyClass.getMethod("create", mediaTypeClass, String.class).invoke(null, mediaType, json);
            
            // 创建 Response.Builder
            Class<?> responseClass = Class.forName("okhttp3.Response", true, call.getClass().getClassLoader());
            Class<?> builderClass = responseClass.getDeclaredClass("Builder");
            Object builder = builderClass.getConstructor().newInstance();
            
            // 设置响应参数
            builderClass.getMethod("request", requestClassName).invoke(builder, request);
            
            Class<?> protocolClass = Class.forName("okhttp3.Protocol", true, call.getClass().getClassLoader());
            Object http2 = protocolClass.getField("HTTP_2").get(null);
            builderClass.getMethod("protocol", protocolClass).invoke(builder, http2);
            
            builderClass.getMethod("code", int.class).invoke(builder, 200);
            builderClass.getMethod("message", String.class).invoke(builder, "OK");
            builderClass.getMethod("body", responseBodyClass).invoke(builder, body);
            
            return builderClass.getMethod("build").invoke(builder);
        } catch (Throwable t) {
            Log.e(TAG, "[NET] 创建伪造响应失败: " + t.getMessage());
            return null;
        }
    }
    
    // ===== Hook 6: 过期检查 =====
    private void hookExpiryChecks(LoadPackageParam lpp) {
        try {
            // 遍历所有类，hook 包含验证关键词的方法
            for (Class<?> clazz : lpp.classLoader.loadAllClasses()) {
                String className = clazz.getName();
                
                if (!className.contains("bienvenido") && !className.contains("mundo")) continue;
                
                for (Method method : clazz.getDeclaredMethods()) {
                    String methodName = method.getName().toLowerCase();
                    
                    if (methodName.contains("expire") || methodName.contains("license") || methodName.contains("valid") || methodName.contains("activat") || methodName.contains("check") || methodName.contains("verify")) {
                        try {
                            XposedBridge.hookMethod(method, new XC_MethodHook() {
                                @Override
                                protected void afterHookedMethod(MethodHookParam param) {
                                    Class<?> returnType = param.method.getReturnType();
                                    if (returnType == boolean.class || returnType == java.lang.Boolean.class) {
                                        param.setResult(true);
                                    } else if (returnType == int.class) {
                                        param.setResult(9999);
                                    }
                                }
                            });
                            Log.i(TAG, "[EXPIRE] Hooked " + className + "." + method.getName());
                        } catch (Throwable t) {
                            // 忽略无法 hook 的方法
                        }
                    }
                }
            }
            
            Log.i(TAG, "[EXPIRE] 过期检查 hook 完成");
        } catch (Throwable t) {
            Log.w(TAG, "[EXPIRE] 过期检查 hook 失败: " + t.getMessage());
        }
    }
}
