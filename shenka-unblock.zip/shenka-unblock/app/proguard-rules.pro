# Keep Xposed classes
-keep class de.robv.android.xposed.** { *; }
-keep class com.unblock.shenka.** { *; }
